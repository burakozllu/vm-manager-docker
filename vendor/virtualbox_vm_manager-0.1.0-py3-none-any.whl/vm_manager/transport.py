from __future__ import annotations

import base64
import json
import subprocess
import tomllib
from pathlib import Path


class ManagerError(Exception):
    """A configuration, SSH, or remote VirtualBox error."""


def load_config(path: Path) -> dict:
    try:
        with path.open("rb") as stream:
            config = tomllib.load(stream)
    except (OSError, tomllib.TOMLDecodeError) as exc:
        raise ManagerError(f"Cannot read config {path}: {exc}") from exc
    host = config.get("host", {})
    for key in ("hostname", "username", "vm_root", "vboxmanage", "sevenzip"):
        if not isinstance(host.get(key), str) or not host[key]:
            raise ManagerError(f"Missing or invalid host.{key} in {path}")
    # These values appear in SSH destinations; forbid option/remote-shell injection.
    import re

    if not re.fullmatch(r"[A-Za-z0-9_.:-]+", host["hostname"]) or host["hostname"].startswith("-"):
        raise ManagerError("Invalid host.hostname")
    if not re.fullmatch(r"[A-Za-z0-9_.-]+", host["username"]) or host["username"].startswith("-"):
        raise ManagerError("Invalid host.username")
    for key, default, maximum in (("port", 22, 65535), ("connect_timeout", 10, 120)):
        value = host.get(key, default)
        if isinstance(value, bool) or not isinstance(value, int) or not 1 <= value <= maximum:
            raise ManagerError(f"Invalid host.{key}")
    defaults = config.setdefault("defaults", {})
    defaults.setdefault("memory", 4096)
    defaults.setdefault("cpus", 2)
    defaults.setdefault("disk", 60)
    defaults.setdefault("ssh_port_start", 2222)
    defaults.setdefault("ssh_access", "tunnel")
    for key, low, high in (("memory", 512, 1048576), ("cpus", 1, 256), ("disk", 10, 2097152), ("ssh_port_start", 1, 65535)):
        value = defaults[key]
        if isinstance(value, bool) or not isinstance(value, int) or not low <= value <= high:
            raise ManagerError(f"Invalid defaults.{key}")
    if defaults["ssh_access"] not in ("tunnel", "lan"):
        raise ManagerError("defaults.ssh_access must be tunnel or lan")
    return config


class Remote:
    def __init__(self, config: dict):
        self.config = config
        self.host = config["host"]

    @property
    def destination(self) -> str:
        return f'{self.host["username"]}@{self.host["hostname"]}'

    def ssh_base(self) -> list[str]:
        return [
            "ssh", "-p", str(self.host.get("port", 22)),
            "-o", "BatchMode=yes", "-o", "StrictHostKeyChecking=accept-new",
            "-o", f'ConnectTimeout={self.host.get("connect_timeout", 10)}',
            "-o", "ServerAliveInterval=15", "-o", "ServerAliveCountMax=3",
            self.destination,
        ]

    def call(self, action: str, *, timeout: int = 180, **params):
        script = Path(__file__).with_name("remote.ps1").read_text(encoding="utf-8")
        request = {"action": action, "host": self.host, "defaults": self.config["defaults"], **params}
        # Data and backend travel on stdin. No user-controlled data enters shell syntax.
        bootstrap = (
            "$ErrorActionPreference='Stop'; "
            "$p=[Console]::In.ReadLine() | ConvertFrom-Json; "
            "& ([scriptblock]::Create($p.script)) -Request $p.request"
        )
        encoded = base64.b64encode(bootstrap.encode("utf-16-le")).decode("ascii")
        command = self.ssh_base() + [f"powershell.exe -NoLogo -NoProfile -NonInteractive -EncodedCommand {encoded}"]
        try:
            result = subprocess.run(
                command, input=json.dumps({"script": script, "request": request}) + "\n",
                capture_output=True, text=True, timeout=timeout,
            )
        except FileNotFoundError as exc:
            raise ManagerError("OpenSSH client is missing; install ssh and scp locally") from exc
        except subprocess.TimeoutExpired as exc:
            raise ManagerError(
                f"Remote operation timed out after {timeout}s. It may still be running; check VM status before retrying."
            ) from exc
        for line in reversed(result.stdout.splitlines()):
            if line.startswith("VM_MANAGER_JSON:"):
                try:
                    response = json.loads(line.removeprefix("VM_MANAGER_JSON:"))
                except json.JSONDecodeError as exc:
                    raise ManagerError("Host returned an invalid JSON response") from exc
                if not response.get("ok"):
                    raise ManagerError(response.get("error", "Unknown remote error"))
                if result.returncode != 0:
                    raise ManagerError(f"SSH exited with code {result.returncode} after responding")
                return response.get("data")
        detail = (result.stderr or result.stdout).strip()
        raise ManagerError(f"Cannot manage {self.destination}: {detail or 'No response from host'}")


def ssh_command(config: dict, info: dict, username: str | None = None, identity: str | None = None) -> list[str]:
    host = config["host"]
    user = username or info.get("ssh_user")
    if not user:
        raise ManagerError("Guest username is unknown. Use --user USER or run ssh-configure NAME --user USER")
    import re

    if not re.fullmatch(r"[A-Za-z0-9_.-]+", user) or user.startswith("-"):
        raise ManagerError("Invalid guest username")
    rules = [rule for rule in info.get("forwards", []) if rule["protocol"] == "tcp" and rule["guest_port"] == 22]
    if not rules:
        raise ManagerError("No SSH forwarding rule. Run ssh-configure NAME --user USER first")
    rule = next((rule for rule in rules if rule["name"] == "vm-manager-ssh"), rules[0])
    command = ["ssh"]
    if identity:
        command += ["-i", str(Path(identity).expanduser())]
    bind = rule["host_ip"]
    if bind in ("127.0.0.1", "::1"):
        jump = f'{host["username"]}@{host["hostname"]}'
        if host.get("port", 22) != 22:
            jump += f':{host["port"]}'
        command += ["-J", jump]
        address = "127.0.0.1"
    else:
        address = host["hostname"]
    # Distinguish guests that all share loopback:22 through the same jump host.
    command += ["-o", f'HostKeyAlias=vm-manager-{host["hostname"]}-{info["uuid"]}',
                "-p", str(rule["host_port"]), f"{user}@{address}"]
    return command

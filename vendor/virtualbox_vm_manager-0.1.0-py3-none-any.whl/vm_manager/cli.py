from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import shlex
import subprocess
import sys
from urllib.error import URLError
from urllib.request import Request, urlopen

from .transport import ManagerError, Remote, load_config, ssh_command


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def positive(low: int, high: int):
    def parse(text):
        try:
            number = int(text)
        except ValueError as exc:
            raise argparse.ArgumentTypeError("must be an integer") from exc
        if not low <= number <= high:
            raise argparse.ArgumentTypeError(f"must be between {low} and {high}")
        return number
    return parse


def new_name(text):
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,63}", text) or text.endswith("."):
        raise argparse.ArgumentTypeError("use 1–64 letters, digits, underscores, dots or hyphens; start with a letter/digit")
    if text.split(".")[0].upper() in {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1, 10)), *(f"LPT{i}" for i in range(1, 10))}:
        raise argparse.ArgumentTypeError("this name is reserved by Windows")
    return text


def checksum(text):
    if not re.fullmatch(r"[0-9a-fA-F]{64}", text):
        raise argparse.ArgumentTypeError("expected a 64-character SHA-256 checksum")
    return text.lower()


def add_resources(parser, disk=False):
    parser.add_argument("--memory", type=positive(512, 1048576), help="RAM in MiB")
    parser.add_argument("--cpus", type=positive(1, 256))
    if disk:
        parser.add_argument("--disk", type=positive(10, 2097152), help="dynamically allocated disk size in GiB")


def add_forward(parser):
    parser.add_argument("--user", help="guest OS username (recorded for SSH commands)")
    parser.add_argument("--ssh-port", type=positive(1, 65535), help="host SSH port; automatically allocated if omitted")
    parser.add_argument("--access", choices=("tunnel", "lan"), help="tunnel through Windows SSH (default) or allow LAN access")


def build_parser():
    parser = argparse.ArgumentParser(description="Manage VirtualBox VMs on your Windows PC over SSH.")
    default_config = PROJECT_ROOT / "config.toml"
    if not default_config.exists():
        default_config = Path.home() / "vm-manager/config.toml"
    parser.add_argument("--config", type=Path, default=Path(os.environ.get("VM_MANAGER_CONFIG", default_config)))
    parser.add_argument("--json", action="store_true", help="machine-readable output")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("doctor", help="check SSH, VirtualBox, disk space and host resources")
    sub.add_parser("list", help="list registered VMs, including existing Kali")
    sub.add_parser("os-types", help="list OS identifiers supported by this VirtualBox installation")
    info = sub.add_parser("info", help="inspect VM configuration and forwarding rules")
    info.add_argument("name")
    for action in ("start", "stop", "restart", "pause", "resume", "save"):
        item = sub.add_parser(action, help={"start": "start or resume a VM", "stop": "request a graceful guest shutdown", "restart": "gracefully restart a VM", "pause": "pause execution", "resume": "resume paused execution", "save": "save VM state to disk"}[action])
        item.add_argument("name")
        if action in ("stop", "restart"):
            item.add_argument("--wait", type=positive(5, 600), default=120, help="shutdown timeout in seconds")
        if action == "stop":
            item.add_argument("--force", action="store_true", help="cut VM power immediately instead of a graceful shutdown")
    create = sub.add_parser("create", help="create a VM from an installer ISO and boot it")
    create.add_argument("name", type=new_name)
    create.add_argument("--iso", required=True, help="Windows host path or HTTPS URL to installer ISO")
    create.add_argument("--sha256", type=checksum)
    create.add_argument("--os-type", default="Debian_64", help="VirtualBox OS ID; see os-types")
    create.add_argument("--firmware", choices=("bios", "efi"), default="bios")
    create.add_argument("--no-start", action="store_true")
    add_resources(create, disk=True)
    add_forward(create)
    imp = sub.add_parser("import", help="import a .ova, .ovf, .vbox or .7z appliance and boot it")
    imp.add_argument("name", type=new_name)
    imp.add_argument("--source", required=True, help="Windows host path or HTTPS URL")
    imp.add_argument("--sha256", type=checksum)
    imp.add_argument("--no-start", action="store_true")
    add_resources(imp)
    add_forward(imp)
    kali = sub.add_parser("deploy-kali", help="download official Kali, configure key-based SSH, and boot it")
    kali.add_argument("name", type=new_name)
    kali.add_argument("--version", help="Kali point release, e.g. 2026.3; default: discover latest")
    kali.add_argument("--public-key", type=Path, default=Path.home() / ".ssh/id_ed25519.pub")
    add_resources(kali)
    add_forward(kali)
    configure = sub.add_parser("configure", help="change RAM/CPU allocation while powered off")
    configure.add_argument("name")
    add_resources(configure)
    eject = sub.add_parser("eject-iso", help="eject installer ISO after OS installation")
    eject.add_argument("name")
    eject.add_argument("--controller", default="SATA")
    eject.add_argument("--port", type=positive(0, 29), default=1)
    remove = sub.add_parser("remove", help="unregister a powered-off VM")
    remove.add_argument("name")
    remove.add_argument("--delete-disks", action="store_true", help="also permanently delete the VM's files and snapshots")
    forward = sub.add_parser("ssh-configure", help="configure host forwarding (guest SSH must already be installed)")
    forward.add_argument("name")
    add_forward(forward)
    for command in ("ssh", "ssh-info"):
        item = sub.add_parser(command, help="open guest SSH" if command == "ssh" else "print the guest SSH connection command")
        item.add_argument("name")
        item.add_argument("--user")
        item.add_argument("--identity", help="guest SSH private key path")
    snapshots = sub.add_parser("snapshot", help="manage VM snapshots")
    snap_sub = snapshots.add_subparsers(dest="snapshot_action", required=True)
    for action in ("list", "create", "restore", "delete"):
        item = snap_sub.add_parser(action)
        item.add_argument("name")
        if action != "list":
            item.add_argument("snapshot")
    auto = sub.add_parser("autostart", help="start a VM when the Windows user signs in")
    auto.add_argument("name")
    auto.add_argument("mode", choices=("enable", "disable", "status"))
    upload = sub.add_parser("upload", help="copy a local ISO/appliance into the host Downloads folder")
    upload.add_argument("file", type=Path)
    return parser


def kali_release(version=None):
    if version is not None and not re.fullmatch(r"[0-9]{4}\.[0-9]+", version):
        raise ManagerError("Invalid Kali version; expected YEAR.RELEASE, e.g. 2026.3")
    # The human-facing website may block automated clients. The download server's
    # current manifest supplies both the release filename and its checksum.
    directory = f"kali-{version}" if version else "current"
    manifest_url = f"https://cdimage.kali.org/{directory}/SHA256SUMS"
    request = Request(manifest_url, headers={"User-Agent": "vm-manager/0.1", "Accept": "text/plain"})
    try:
        with urlopen(request, timeout=30) as response:
            manifest = response.read(4 * 1024 * 1024).decode("utf-8")
    except (OSError, URLError, UnicodeError) as exc:
        raise ManagerError(f"Could not fetch {manifest_url}: {exc}") from exc
    images = []
    for line in manifest.splitlines():
        match = re.fullmatch(
            r"([a-fA-F0-9]{64})[ \t]+\*?(kali-linux-([0-9]{4}\.[0-9]+)-virtualbox-amd64\.7z)",
            line.strip(),
        )
        if match and (version is None or match.group(3) == version):
            images.append(match)
    if not images:
        expected = f"kali-linux-{version}-virtualbox-amd64.7z" if version else "a Kali VirtualBox amd64 image"
        raise ManagerError(f"No checksum published for {expected} in {manifest_url}")
    image = max(images, key=lambda match: tuple(map(int, match.group(3).split("."))))
    # Pin the version instead of downloading from a mutable 'current' URL.
    return f"https://cdimage.kali.org/kali-{image.group(3)}/{image.group(2)}", image.group(1).lower()


def deploy_kali(remote, args, config):
    try:
        key = args.public_key.expanduser().read_text().strip()
    except OSError as exc:
        raise ManagerError(f"Cannot read public key {args.public_key}: {exc}") from exc
    if not re.fullmatch(r"(?:ssh-ed25519|ssh-rsa|ecdsa-sha2-\S+) [A-Za-z0-9+/=]+(?: [^\r\n]*)?", key):
        raise ManagerError("Expected one OpenSSH public key")
    if args.user and args.user != "kali":
        raise ManagerError("Official Kali images use the user kali; omit --user or use --user kali")
    source, digest = kali_release(args.version)
    password = secrets.token_urlsafe(24)
    info = remote.call("import", timeout=7200, name=args.name, source=source, sha256=digest,
                       memory=args.memory or 8192, cpus=args.cpus or 4, user="kali",
                       ssh_port=args.ssh_port, access=args.access or config["defaults"]["ssh_access"], start=True)
    try:
        remote.call("setup-kali", timeout=300, name=args.name, public_key=key, password=password)
    except ManagerError as exc:
        raise ManagerError(
            f"VM {args.name} was imported and started, but SSH provisioning did not complete: {exc}. "
            "Inspect its console and SSH before retrying; the password may already have changed. "
            f"Generated password: {password}"
        ) from exc
    info["initial_password"] = password
    info["ssh_command"] = shlex.join(ssh_command(config, info, "kali"))
    return info


def upload_file(remote, file):
    file = file.expanduser().resolve()
    if not file.is_file():
        raise ManagerError(f"Local file does not exist: {file}")
    with file.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    safe_name = re.sub(r"[^A-Za-z0-9_.-]", "_", file.name)
    target = remote.call("upload-target", filename=f"{digest[:16]}-{safe_name}")
    host = remote.host
    windows_path = target["path"].replace("\\", "/")
    command = ["scp", "-P", str(host.get("port", 22)), "-o", "BatchMode=yes",
               "-o", "StrictHostKeyChecking=accept-new", "-o", f'ConnectTimeout={host.get("connect_timeout", 10)}',
               str(file), f"{remote.destination}:{windows_path}.partial"]
    try:
        result = subprocess.run(command)
    except OSError as exc:
        raise ManagerError(f"Could not upload file: {exc}") from exc
    if result.returncode:
        raise ManagerError("SCP upload failed; partial file remains on the host")
    return remote.call("upload-finish", timeout=600, path=target["path"], sha256=digest)


def execute(args, config):
    remote = Remote(config)
    action = args.command
    if action == "deploy-kali":
        return deploy_kali(remote, args, config)
    if action == "upload":
        return upload_file(remote, args.file)
    if action in ("ssh", "ssh-info"):
        info = remote.call("info", name=args.name)
        command = ssh_command(config, info, args.user, args.identity)
        if action == "ssh-info":
            return {"name": info["name"], "state": info["state"], "command": shlex.join(command)}
        if args.json:
            raise ManagerError("--json cannot be used with an interactive SSH session; use ssh-info")
        if info["state"] != "running":
            raise ManagerError(f"VM is {info['state']}; run start {args.name!r} first")
        returncode = subprocess.call(command)
        if returncode:
            raise ManagerError(f"Guest SSH exited with code {returncode}")
        return None
    params = {key: value for key, value in vars(args).items()
              if key not in ("command", "config", "json") and value is not None}
    if action in ("create", "import"):
        params["start"] = not params.pop("no_start")
        for key in ("memory", "cpus") + (("disk",) if action == "create" else ()):
            if key not in params and action == "create":
                params[key] = config["defaults"][key]
        params.setdefault("access", config["defaults"]["ssh_access"])
    if action == "configure" and not (args.memory or args.cpus):
        raise ManagerError("Specify --memory and/or --cpus")
    timeout = 7200 if action in ("create", "import") else max(180, params.get("wait", 120) + 60)
    data = remote.call(action, timeout=timeout, **params)
    return data


def display(data, as_json=False):
    if data is None:
        return
    if as_json:
        print(json.dumps(data, indent=2, ensure_ascii=False))
    elif isinstance(data, list):
        if not data:
            print("No entries.")
        elif all(isinstance(row, dict) and "name" in row and "state" in row for row in data):
            print(f"{'NAME':<28} {'STATE':<14} {'RAM MiB':>8} {'CPUs':>5}  SSH HOST PORT(S)")
            for row in data:
                ports = ", ".join(str(rule["host_port"]) for rule in row.get("forwards", []) if rule["guest_port"] == 22)
                print(f"{row['name']:<28} {row['state']:<14} {row['memory']:>8} {row['cpus']:>5}  {ports or '-'}")
        else:
            print(json.dumps(data, indent=2, ensure_ascii=False))
    elif isinstance(data, dict) and "command" in data:
        print(data["command"])
    else:
        print(json.dumps(data, indent=2, ensure_ascii=False))


def main(argv=None):
    args = build_parser().parse_args(argv)
    try:
        config = load_config(args.config.expanduser())
        display(execute(args, config), args.json)
        return 0
    except (ManagerError, OSError) as exc:
        if args.json:
            print(json.dumps({"error": str(exc)}))
        else:
            print(f"Error: {exc}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\nInterrupted. Check VM status before retrying a deployment.", file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())

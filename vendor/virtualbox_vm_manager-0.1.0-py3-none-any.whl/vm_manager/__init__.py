"""Remote VirtualBox management without third-party Python dependencies."""

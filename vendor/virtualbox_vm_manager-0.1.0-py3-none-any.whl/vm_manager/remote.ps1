param([Parameter(Mandatory = $true)] $Request)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$VBox = $Request.host.vboxmanage
$Root = $Request.host.vm_root

function Invoke-VBox {
    param([Parameter(ValueFromRemainingArguments = $true)][string[]] $Arguments)
    # PS 5.1 treats native stderr as ErrorRecords; capture it without terminating.
    $old = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        $output = @(& $VBox @Arguments 2>&1 | ForEach-Object { $_.ToString() })
        $code = $LASTEXITCODE
    } finally { $ErrorActionPreference = $old }
    if ($code -ne 0) { throw "VBoxManage $($Arguments[0]) failed: $($output -join [Environment]::NewLine)" }
    return $output
}

function Get-Properties([string] $Name) {
    $properties = @{}
    foreach ($line in (Invoke-VBox showvminfo $Name --machinereadable)) {
        if ($line -match '^([^=]+)=(.*)$') {
            $key = $Matches[1].Trim('"')
            $value = $Matches[2]
            if ($value.StartsWith('"') -and $value.EndsWith('"')) {
                try { $value = ConvertFrom-Json -InputObject $value } catch { $value = $value.Trim('"') }
            }
            $properties[$key] = $value
        }
    }
    return $properties
}

function Get-VM([string] $Name) {
    $p = Get-Properties $Name
    $forwards = @()
    foreach ($key in $p.Keys) {
        if ($key -match '^Forwarding\(') {
            $parts = $p[$key].Split(',')
            if ($parts.Count -eq 6) {
                $forwards += [pscustomobject]@{
                    name = $parts[0]; protocol = $parts[1]; host_ip = $parts[2]
                    host_port = [int]$parts[3]; guest_ip = $parts[4]; guest_port = [int]$parts[5]
                }
            }
        }
    }
    $user = $null
    $extra = @(Invoke-VBox getextradata $Name 'vm-manager/ssh-user')
    if ($extra.Count -and $extra[0] -match '^Value: (.+)$') { $user = $Matches[1] }
    if (-not $user -and $p['name'] -match '(?i)kali') { $user = 'kali' }
    return [pscustomobject]@{
        name = $p['name']; uuid = $p['UUID']; state = $p['VMState']
        memory = [int]$p['memory']; cpus = [int]$p['cpus']; os_type = $p['ostype']
        config = $p['CfgFile']; ssh_user = $user; forwards = @($forwards)
    }
}

function Get-AllVMs {
    $vms = @()
    foreach ($line in (Invoke-VBox list vms)) {
        if ($line -match '^"(.*)" \{([0-9a-f-]+)\}$') { $vms += Get-VM $Matches[2] }
    }
    return ,$vms
}

function Assert-NewName([string] $Name) {
    if ($Name -notmatch '^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$' -or $Name.EndsWith('.')) {
        throw 'Invalid VM name'
    }
    if (($Name.Split('.')[0]) -match '^(?i:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])$') { throw 'Reserved Windows filename' }
    foreach ($vm in (Get-AllVMs)) {
        if ($vm.name -ieq $Name) { throw "VM '$Name' already exists; use start or import under another name" }
    }
    if (Test-Path -LiteralPath (Join-Path $Root $Name)) { throw "Directory already exists: $(Join-Path $Root $Name)" }
}

function Assert-Off($VM) {
    if ($VM.state -notin @('poweroff', 'aborted')) { throw "VM '$($VM.name)' is $($VM.state); stop it first" }
}

function Start-VM([string] $Name) {
    $vm = Get-VM $Name
    switch ($vm.state) {
        'running' { return $vm }
        'paused' { Invoke-VBox controlvm $vm.uuid resume | Out-Null }
        { $_ -in @('poweroff', 'aborted', 'saved') } { Invoke-VBox startvm $vm.uuid --type headless | Out-Null }
        default { throw "Cannot start a VM in state $($vm.state)" }
    }
    return Get-VM $vm.uuid
}

function Stop-VM([string] $Name, [int] $WaitSeconds = 120, [bool] $Force = $false) {
    $vm = Get-VM $Name
    if ($vm.state -in @('poweroff', 'aborted')) { return $vm }
    if ($Force) {
        if ($vm.state -eq 'saved') { throw 'VM is saved; start it before powering it off' }
        Invoke-VBox controlvm $vm.uuid poweroff | Out-Null
        return Get-VM $vm.uuid
    }
    if ($vm.state -eq 'paused') { Invoke-VBox controlvm $vm.uuid resume | Out-Null }
    elseif ($vm.state -ne 'running') { throw "Cannot gracefully stop a VM in state $($vm.state)" }
    Invoke-VBox controlvm $vm.uuid acpipowerbutton | Out-Null
    $end = (Get-Date).AddSeconds($WaitSeconds)
    do {
        Start-Sleep -Seconds 2
        $vm = Get-VM $vm.uuid
        if ($vm.state -in @('poweroff', 'aborted')) { return $vm }
    } while ((Get-Date) -lt $end)
    throw "Guest did not shut down in $WaitSeconds seconds. Check its console, or explicitly use stop --force"
}

function Resolve-Source([string] $Source, [string] $SHA256) {
    if ($Source -match '^https://') {
        $uri = [Uri]$Source
        $filename = [IO.Path]::GetFileName($uri.AbsolutePath)
        if (-not $filename -or $filename -match '[^A-Za-z0-9_.-]') { throw 'URL must end with a plain ISO/appliance filename' }
        $downloadDir = Join-Path $Root 'Downloads'
        New-Item -ItemType Directory -Path $downloadDir -Force | Out-Null
        # Include URL identity so different mirrors/paths cannot reuse an unrelated file.
        $hasher = [Security.Cryptography.SHA256]::Create()
        try { $urlHash = [BitConverter]::ToString($hasher.ComputeHash([Text.Encoding]::UTF8.GetBytes($Source))).Replace('-', '').Substring(0, 12) }
        finally { $hasher.Dispose() }
        $path = Join-Path $downloadDir "$urlHash-$filename"
        if (-not (Test-Path -LiteralPath $path)) {
            $partial = "$path.partial"
            $old = $ErrorActionPreference
            $ErrorActionPreference = 'Continue'
            try {
                $output = @(& curl.exe --location --fail --retry 3 --silent --show-error --output $partial $Source 2>&1)
                $code = $LASTEXITCODE
            } finally { $ErrorActionPreference = $old }
            if ($code -ne 0) { throw "Download failed: $($output -join ' ')" }
            if ($SHA256 -and (Get-FileHash -LiteralPath $partial -Algorithm SHA256).Hash -ine $SHA256) {
                Remove-Item -LiteralPath $partial
                throw 'Downloaded file SHA-256 does not match; partial file removed'
            }
            Move-Item -LiteralPath $partial -Destination $path
        }
    } else {
        if ($Source -match '^[a-zA-Z]+://') { throw 'Use an HTTPS URL or an absolute Windows host path' }
        if (-not [IO.Path]::IsPathRooted($Source)) { throw 'Source must be an absolute Windows host path or HTTPS URL; upload local files first' }
        $path = $Source
    }
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "Source file does not exist on host: $path" }
    if ($SHA256 -and (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ine $SHA256) { throw "SHA-256 mismatch: $path" }
    return $path
}

function Get-SSHPort([int] $RequestedPort, [string] $ExcludeUUID) {
    $used = @{}
    foreach ($vm in (Get-AllVMs)) {
        foreach ($rule in $vm.forwards) {
            if ($vm.uuid -ne $ExcludeUUID -or $rule.name -ne 'vm-manager-ssh') { $used[$rule.host_port] = $true }
        }
    }
    # Include host listeners; the current managed forward is reusable when reconfiguring.
    foreach ($entry in @(Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue)) {
        $used[[int]$entry.LocalPort] = $true
    }
    if ($RequestedPort) {
        if ($used.ContainsKey($RequestedPort)) { throw "TCP port $RequestedPort is already allocated or listening" }
        return $RequestedPort
    }
    for ($port = [int]$Request.defaults.ssh_port_start; $port -le 65535; $port++) {
        if (-not $used.ContainsKey($port)) { return $port }
    }
    throw 'No free SSH port found'
}

function Set-SSHForward([string] $Name, [string] $UserName, [int] $Port, [string] $Access) {
    $vm = Get-VM $Name
    if ($vm.state -notin @('poweroff', 'aborted', 'running', 'paused')) { throw "Cannot update SSH forwarding in state $($vm.state)" }
    if ($UserName -and ($UserName -notmatch '^[A-Za-z0-9_][A-Za-z0-9_.-]*$')) { throw 'Invalid SSH username' }
    if (-not $Access) { $Access = $Request.defaults.ssh_access }
    if ($Access -notin @('tunnel', 'lan')) { throw 'Invalid SSH access mode' }
    $p = Get-Properties $vm.uuid
    if ($p['nic1'] -ne 'nat') { throw 'SSH forwarding requires NAT on adapter 1; configure this VM network in VirtualBox first' }
    $existing = @($vm.forwards | Where-Object { $_.protocol -eq 'tcp' -and $_.guest_port -eq 22 })
    # Omitted port preserves the current managed allocation.
    if (-not $Port -and $existing.Count) { $Port = $existing[0].host_port }
    $reusing = @($existing | Where-Object { $_.host_port -eq $Port }).Count -gt 0
    if (-not $reusing) { $Port = Get-SSHPort $Port $vm.uuid }
    $bind = '127.0.0.1'
    if ($Access -eq 'lan') { $bind = $Request.host.hostname }
    $rule = "vm-manager-ssh,tcp,$bind,$Port,,22"
    $live = $vm.state -in @('running', 'paused')
    foreach ($old in $existing) {
        if ($live) { Invoke-VBox controlvm $vm.uuid natpf1 delete $old.name | Out-Null }
        else { Invoke-VBox modifyvm $vm.uuid --natpf1 delete $old.name | Out-Null }
    }
    try {
        if ($live) { Invoke-VBox controlvm $vm.uuid natpf1 $rule | Out-Null }
        else { Invoke-VBox modifyvm $vm.uuid --natpf1 $rule | Out-Null }
    } catch {
        foreach ($old in $existing) {
            $oldRule = "$($old.name),$($old.protocol),$($old.host_ip),$($old.host_port),$($old.guest_ip),$($old.guest_port)"
            if ($live) { Invoke-VBox controlvm $vm.uuid natpf1 $oldRule | Out-Null }
            else { Invoke-VBox modifyvm $vm.uuid --natpf1 $oldRule | Out-Null }
        }
        throw
    }
    $firewallName = "vm-manager-ssh-$($vm.uuid)"
    if ($Access -eq 'lan') {
        Get-NetFirewallRule -Name $firewallName -ErrorAction SilentlyContinue | Remove-NetFirewallRule
        New-NetFirewallRule -Name $firewallName -DisplayName "VM Manager SSH: $($vm.name)" -Direction Inbound -Action Allow -Protocol TCP -LocalAddress $bind -LocalPort $Port -RemoteAddress LocalSubnet | Out-Null
    } else {
        Get-NetFirewallRule -Name $firewallName -ErrorAction SilentlyContinue | Remove-NetFirewallRule
    }
    if ($UserName) { Invoke-VBox setextradata $vm.uuid 'vm-manager/ssh-user' $UserName | Out-Null }
    return Get-VM $vm.uuid
}

function New-VM {
    Assert-NewName $Request.name
    $iso = Resolve-Source $Request.iso $Request.sha256
    if ([IO.Path]::GetExtension($iso) -ine '.iso') { throw 'create requires an ISO image' }
    New-Item -ItemType Directory -Path $Root -Force | Out-Null
    $created = $false
    try {
        Invoke-VBox createvm --name $Request.name --ostype $Request.os_type --basefolder $Root --register | Out-Null
        $created = $true
        $firmware = $Request.firmware
        if ($Request.os_type -eq 'Windows11_64') { $firmware = 'efi' }
        $graphics = 'vmsvga'
        if ($Request.os_type -match '^Windows') { $graphics = 'vboxsvga' }
        Invoke-VBox modifyvm $Request.name --memory $Request.memory --cpus $Request.cpus --nic1 nat --graphicscontroller $graphics --vram 128 --ioapic on --firmware $firmware --boot1 dvd --boot2 disk | Out-Null
        if ($Request.os_type -eq 'Windows11_64') { Invoke-VBox modifyvm $Request.name --tpm-type 2.0 | Out-Null }
        $disk = Join-Path (Join-Path $Root $Request.name) "$($Request.name).vdi"
        Invoke-VBox createmedium disk --filename $disk --size ([int64]$Request.disk * 1024) --format VDI --variant Standard | Out-Null
        Invoke-VBox storagectl $Request.name --name SATA --add sata --controller IntelAhci --portcount 2 | Out-Null
        Invoke-VBox storageattach $Request.name --storagectl SATA --port 0 --device 0 --type hdd --medium $disk | Out-Null
        Invoke-VBox storageattach $Request.name --storagectl SATA --port 1 --device 0 --type dvddrive --medium $iso | Out-Null
        Set-SSHForward $Request.name $Request.user $Request.ssh_port $Request.access | Out-Null
        Invoke-VBox setextradata $Request.name 'vm-manager/created' 'true' | Out-Null
    } catch {
        if ($created) {
            # Retain files for recovery, but do not leave a partially configured VM registered.
            try { Invoke-VBox unregistervm $Request.name | Out-Null } catch { }
        }
        throw
    }
    if ($Request.start) { return Start-VM $Request.name }
    return Get-VM $Request.name
}

function Import-VM {
    Assert-NewName $Request.name
    $source = Resolve-Source $Request.source $Request.sha256
    $extension = [IO.Path]::GetExtension($source).ToLowerInvariant()
    $registered = $null
    try {
        if ($extension -eq '.7z') {
            if (-not (Test-Path -LiteralPath $Request.host.sevenzip)) { throw '7-Zip is missing on host; install 7zip.7zip using winget' }
            $staging = Join-Path (Join-Path $Root 'Imports') ([Guid]::NewGuid().ToString())
            New-Item -ItemType Directory -Path $staging -Force | Out-Null
            $old = $ErrorActionPreference
            $ErrorActionPreference = 'Continue'
            try {
                $output = @(& $Request.host.sevenzip x $source "-o$staging" -y -bsp0 2>&1)
                $code = $LASTEXITCODE
            } finally { $ErrorActionPreference = $old }
            if ($code -ne 0) { throw "7-Zip extraction failed: $($output -join ' ')" }
            $configs = @(Get-ChildItem -LiteralPath $staging -Recurse -Filter '*.vbox')
            if ($configs.Count -ne 1) { throw 'Archive must contain exactly one .vbox VM configuration' }
            $source = $configs[0].FullName
            $extension = '.vbox'
        }
        if ($extension -eq '.vbox') {
            [xml]$xml = Get-Content -LiteralPath $source -Raw
            if ($xml.SelectNodes("//*[local-name()='Snapshot']").Count) {
                throw 'Importing .vbox snapshot trees is not supported; export an OVA appliance instead'
            }
            # Copy raw configurations, or move the extracted archive, into a new VM directory.
            # Assign fresh machine/media UUIDs so multiple copies of one appliance coexist.
            $vmDirectory = Join-Path $Root $Request.name
            $sourceDirectory = Split-Path -Parent $source
            $configFilename = Split-Path -Leaf $source
            $sourcePrefix = [IO.Path]::GetFullPath($sourceDirectory).TrimEnd('\') + '\'
            if ([IO.Path]::GetFullPath($vmDirectory).StartsWith($sourcePrefix, [StringComparison]::OrdinalIgnoreCase)) {
                throw 'Source directory contains the destination; move the appliance into its own directory first'
            }
            if ($staging) { Move-Item -LiteralPath $sourceDirectory -Destination $vmDirectory }
            else { Copy-Item -LiteralPath $sourceDirectory -Destination $vmDirectory -Recurse }
            $source = Join-Path $vmDirectory $configFilename
            $machine = $xml.SelectSingleNode("//*[local-name()='Machine']")
            if (-not $machine) { throw 'Invalid .vbox file: no Machine element' }
            $uuid = [Guid]::NewGuid().ToString()
            $machine.SetAttribute('uuid', "{$uuid}")
            $machine.SetAttribute('name', $Request.name)
            $mediaMap = @{}
            $allowedDirectory = [IO.Path]::GetFullPath($vmDirectory).TrimEnd('\') + '\'
            foreach ($medium in $xml.SelectNodes("//*[local-name()='HardDisk']")) {
                if ($medium.ParentNode.LocalName -eq 'HardDisk') { throw 'Differencing disks require export as an OVA appliance' }
                $location = $medium.GetAttribute('location')
                if ([IO.Path]::IsPathRooted($location)) { throw 'A .vbox disk uses an absolute path; export an OVA appliance instead' }
                $diskPath = [IO.Path]::GetFullPath((Join-Path $vmDirectory $location))
                if (-not $diskPath.StartsWith($allowedDirectory, [StringComparison]::OrdinalIgnoreCase)) { throw 'Disk must be inside the appliance directory' }
                $oldUUID = $medium.GetAttribute('uuid')
                $newUUID = [Guid]::NewGuid().ToString()
                Invoke-VBox internalcommands sethduuid $diskPath $newUUID | Out-Null
                $mediaMap[$oldUUID] = "{$newUUID}"
                $medium.SetAttribute('uuid', "{$newUUID}")
            }
            foreach ($image in $xml.SelectNodes("//*[local-name()='Image']")) {
                $oldUUID = $image.GetAttribute('uuid')
                if ($mediaMap.ContainsKey($oldUUID)) { $image.SetAttribute('uuid', $mediaMap[$oldUUID]) }
            }
            $xml.Save($source)
            Invoke-VBox registervm $source | Out-Null
            $registered = $uuid
            # Generate new MACs for cloned adapters rather than reusing an appliance identity.
            $properties = Get-Properties $uuid
            for ($adapter = 1; $adapter -le 8; $adapter++) {
                if ($properties["nic$adapter"] -and $properties["nic$adapter"] -ne 'none') {
                    Invoke-VBox modifyvm $uuid "--macaddress$adapter" auto | Out-Null
                }
            }
            if ($staging -and (Test-Path -LiteralPath $staging)) { Remove-Item -LiteralPath $staging -Recurse -Force }
        } elseif ($extension -in @('.ova', '.ovf')) {
            $preview = @(Invoke-VBox import $source --dry-run)
            $systems = @($preview | Where-Object { $_ -match '^Virtual system [0-9]+:' })
            if ($systems.Count -ne 1) { throw 'Import requires an OVF/OVA appliance describing exactly one virtual system' }
            Invoke-VBox import $source --vsys 0 --vmname $Request.name --basefolder $Root | Out-Null
            $registered = $Request.name
        } else { throw 'Supported imports: .ova, .ovf, .vbox, .7z containing a single VirtualBox VM' }
        $vm = Get-VM $registered
        Assert-Off $vm
        if ($Request.memory) { Invoke-VBox modifyvm $vm.uuid --memory $Request.memory | Out-Null }
        if ($Request.cpus) { Invoke-VBox modifyvm $vm.uuid --cpus $Request.cpus | Out-Null }
        # Preserve appliance networking. Only NAT appliances receive a forwarding rule.
        $properties = Get-Properties $vm.uuid
        if ($properties['nic1'] -eq 'nat') {
            # A cloned appliance must not retain the original VM's host SSH port.
            foreach ($forward in $vm.forwards) {
                if ($forward.protocol -eq 'tcp' -and $forward.guest_port -eq 22) {
                    Invoke-VBox modifyvm $vm.uuid --natpf1 delete $forward.name | Out-Null
                }
            }
            Set-SSHForward $vm.uuid $Request.user $Request.ssh_port $Request.access | Out-Null
        }
        elseif ($Request.ssh_port -or $Request.user) { throw 'Imported appliance adapter 1 is not NAT; configure its network in VirtualBox first' }
        Invoke-VBox setextradata $vm.uuid 'vm-manager/created' 'true' | Out-Null
    } catch {
        if ($registered) { try { Invoke-VBox unregistervm $registered | Out-Null } catch { } }
        throw
    }
    if ($Request.start) { return Start-VM $Request.name }
    return Get-VM $Request.name
}

function Initialize-Kali {
    $vm = Get-VM $Request.name
    if ($vm.state -ne 'running') { throw 'Kali VM must be running' }
    $end = (Get-Date).AddSeconds(180)
    do {
        $properties = @(Invoke-VBox guestproperty get $vm.uuid '/VirtualBox/GuestAdd/Version')
        if ($properties.Count -and $properties[0] -match '^Value: ') { break }
        Start-Sleep -Seconds 3
    } while ((Get-Date) -lt $end)
    if ((Get-Date) -ge $end) { throw 'Guest Additions did not become ready in 180 seconds' }
    $key64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($Request.public_key))
    $password64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($Request.password))
    # No secret appears in process arguments. The temporary script is deleted on both sides.
    $guestScript = @'
#!/bin/bash
set -euo pipefail
if [[ $EUID -ne 0 ]]; then
    exec sudo -S /bin/bash "$0" --root <<<'kali'
fi
trap 'rm -f -- "$0"' EXIT
install -d -m 700 -o kali -g kali /home/kali/.ssh
touch /home/kali/.ssh/authorized_keys
key=$(printf '%s' '__KEY64__' | base64 -d)
grep -qxF "$key" /home/kali/.ssh/authorized_keys || printf '%s\n' "$key" >> /home/kali/.ssh/authorized_keys
chown kali:kali /home/kali/.ssh/authorized_keys
chmod 600 /home/kali/.ssh/authorized_keys
password=$(printf '%s' '__PASSWORD64__' | base64 -d)
printf 'kali:%s\n' "$password" | chpasswd
rm -f /etc/ssh/ssh_host_*_key /etc/ssh/ssh_host_*_key.pub
ssh-keygen -A
/usr/sbin/sshd -t
systemctl enable --now ssh
systemctl is-active --quiet ssh
'@
    $guestScript = $guestScript.Replace('__KEY64__', $key64).Replace('__PASSWORD64__', $password64).Replace("`r`n", "`n")
    $id = [Guid]::NewGuid().ToString('N')
    $hostScript = Join-Path $env:TEMP "vm-manager-$id.sh"
    $guestPath = "/home/kali/vm-manager-$id.sh"
    try {
        [IO.File]::WriteAllText($hostScript, $guestScript, (New-Object Text.UTF8Encoding($false)))
        Invoke-VBox guestcontrol $vm.uuid copyto --username kali --password kali $hostScript $guestPath | Out-Null
        Invoke-VBox guestcontrol $vm.uuid run --exe /bin/bash --username kali --password kali --timeout 60000 --wait-stdout --wait-stderr -- $guestPath | Out-Null
        return [pscustomobject]@{ name = $vm.name; ssh_configured = $true }
    } finally { Remove-Item -LiteralPath $hostScript -Force -ErrorAction SilentlyContinue }
}

function Invoke-Request {
    if (-not (Test-Path -LiteralPath $VBox -PathType Leaf)) { throw "VirtualBox is missing: $VBox" }
    switch ($Request.action) {
        'doctor' {
            $os = Get-CimInstance Win32_OperatingSystem
            $computer = Get-CimInstance Win32_ComputerSystem
            $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
            $principal = New-Object Security.Principal.WindowsPrincipal($identity)
            return [pscustomobject]@{
                host = $env:COMPUTERNAME; user = $identity.Name; os = $os.Caption
                virtualbox = (Invoke-VBox --version) -join ''; vm_root = $Root
                logical_cpus = $computer.NumberOfLogicalProcessors
                memory_total_gib = [Math]::Round($computer.TotalPhysicalMemory / 1GB, 1)
                memory_free_gib = [Math]::Round($os.FreePhysicalMemory / 1MB, 1)
                elevated = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
                sevenzip = Test-Path -LiteralPath $Request.host.sevenzip
                disks = @(Get-PSDrive -PSProvider FileSystem | Select-Object Name, @{n='free_gib'; e={[Math]::Round($_.Free / 1GB, 1)}})
            }
        }
        'list' { return ,(Get-AllVMs) }
        'os-types' { return ,@(Invoke-VBox list ostypes) }
        'info' { return Get-VM $Request.name }
        'start' { return Start-VM $Request.name }
        'stop' { return Stop-VM $Request.name $Request.wait ([bool]$Request.force) }
        'restart' {
            Stop-VM $Request.name $Request.wait | Out-Null
            return Start-VM $Request.name
        }
        'pause' {
            $vm = Get-VM $Request.name
            if ($vm.state -eq 'paused') { return $vm }
            if ($vm.state -ne 'running') { throw 'Only a running VM can be paused' }
            Invoke-VBox controlvm $vm.uuid pause | Out-Null
            return Get-VM $vm.uuid
        }
        'resume' {
            $vm = Get-VM $Request.name
            if ($vm.state -eq 'running') { return $vm }
            if ($vm.state -ne 'paused') { throw 'Only a paused VM can be resumed; use start for saved VMs' }
            Invoke-VBox controlvm $vm.uuid resume | Out-Null
            return Get-VM $vm.uuid
        }
        'save' {
            $vm = Get-VM $Request.name
            if ($vm.state -eq 'saved') { return $vm }
            if ($vm.state -notin @('running', 'paused')) { throw 'Only running or paused VMs can be saved' }
            Invoke-VBox controlvm $vm.uuid savestate | Out-Null
            return Get-VM $vm.uuid
        }
        'create' { return New-VM }
        'import' { return Import-VM }
        'setup-kali' { return Initialize-Kali }
        'configure' {
            $vm = Get-VM $Request.name
            Assert-Off $vm
            if ($Request.memory) { Invoke-VBox modifyvm $vm.uuid --memory $Request.memory | Out-Null }
            if ($Request.cpus) { Invoke-VBox modifyvm $vm.uuid --cpus $Request.cpus | Out-Null }
            return Get-VM $vm.uuid
        }
        'eject-iso' {
            $vm = Get-VM $Request.name
            # VBoxManage refuses an incompatible storage type, so this cannot eject an HDD.
            $p = Get-Properties $vm.uuid
            $slot = "$($Request.controller)-$($Request.port)-0"
            if (-not $p.ContainsKey($slot)) { throw "Storage slot does not exist: $slot" }
            $medium = $p[$slot]
            if ($medium -notin @('emptydrive', 'none') -and [IO.Path]::GetExtension($medium) -ine '.iso') {
                throw 'The selected slot is not an ISO/DVD drive'
            }
            Invoke-VBox storageattach $vm.uuid --storagectl $Request.controller --port $Request.port --device 0 --type dvddrive --medium emptydrive | Out-Null
            return Get-VM $vm.uuid
        }
        'remove' {
            $vm = Get-VM $Request.name
            Assert-Off $vm
            if ($Request.delete_disks) { Invoke-VBox unregistervm $vm.uuid --delete | Out-Null }
            else { Invoke-VBox unregistervm $vm.uuid | Out-Null }
            Unregister-ScheduledTask -TaskName "vm-manager-$($vm.uuid)" -Confirm:$false -ErrorAction SilentlyContinue
            Get-NetFirewallRule -Name "vm-manager-ssh-$($vm.uuid)" -ErrorAction SilentlyContinue | Remove-NetFirewallRule
            return [pscustomobject]@{ name = $vm.name; removed = $true; files_deleted = [bool]$Request.delete_disks }
        }
        'ssh-configure' { return Set-SSHForward $Request.name $Request.user $Request.ssh_port $Request.access }
        'snapshot' {
            $vm = Get-VM $Request.name
            switch ($Request.snapshot_action) {
                'list' { return ,@(Invoke-VBox snapshot $vm.uuid list --machinereadable) }
                'create' { Invoke-VBox snapshot $vm.uuid take $Request.snapshot | Out-Null }
                'restore' { Assert-Off $vm; Invoke-VBox snapshot $vm.uuid restore $Request.snapshot | Out-Null }
                'delete' { Invoke-VBox snapshot $vm.uuid delete $Request.snapshot | Out-Null }
                default { throw 'Invalid snapshot action' }
            }
            return [pscustomobject]@{ name = $vm.name; action = $Request.snapshot_action; snapshot = $Request.snapshot }
        }
        'autostart' {
            $vm = Get-VM $Request.name
            $taskName = "vm-manager-$($vm.uuid)"
            switch ($Request.mode) {
                'enable' {
                    $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent().Name
                    $action = New-ScheduledTaskAction -Execute $VBox -Argument "startvm $($vm.uuid) --type headless"
                    $trigger = New-ScheduledTaskTrigger -AtLogOn -User $currentUser
                    $principal = New-ScheduledTaskPrincipal -UserId $currentUser -LogonType Interactive -RunLevel Highest
                    $settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
                    Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force | Out-Null
                }
                'disable' { Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue }
                'status' { }
                default { throw 'Invalid autostart mode' }
            }
            $task = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
            return [pscustomobject]@{ name = $vm.name; enabled = [bool]$task; task = $taskName; trigger = 'Windows user sign-in' }
        }
        'upload-target' {
            if ($Request.filename -notmatch '^[A-Za-z0-9_.-]+$' -or $Request.filename -in @('.', '..')) { throw 'Invalid upload filename' }
            $directory = Join-Path $Root Downloads
            New-Item -ItemType Directory -Path $directory -Force | Out-Null
            return [pscustomobject]@{ path = Join-Path $directory $Request.filename }
        }
        'upload-finish' {
            $downloads = [IO.Path]::GetFullPath((Join-Path $Root Downloads)).TrimEnd('\') + '\'
            $path = [IO.Path]::GetFullPath($Request.path)
            if (-not $path.StartsWith($downloads, [StringComparison]::OrdinalIgnoreCase)) { throw 'Upload path must be inside Downloads' }
            $partial = "$path.partial"
            if ((Get-FileHash -LiteralPath $partial -Algorithm SHA256).Hash -ine $Request.sha256) { throw 'Uploaded file SHA-256 mismatch' }
            Move-Item -LiteralPath $partial -Destination $path -Force
            return [pscustomobject]@{ path = $path; sha256 = $Request.sha256 }
        }
        default { throw "Unknown action: $($Request.action)" }
    }
}

$mutex = $null
$acquired = $false
try {
    # Serialize transactions across CLI processes, including port allocation and snapshots.
    $mutex = [Threading.Mutex]::new($false, 'Global\VMManager-VirtualBox')
    try { $acquired = $mutex.WaitOne([TimeSpan]::FromSeconds(60)) }
    catch [Threading.AbandonedMutexException] { $acquired = $true }
    if (-not $acquired) { throw 'Another VM Manager operation is still running; retry when it finishes' }
    $data = Invoke-Request
    $response = @{ ok = $true; data = $data }
} catch {
    $response = @{ ok = $false; error = $_.Exception.Message }
} finally {
    if ($mutex) {
        if ($acquired) { $mutex.ReleaseMutex() }
        $mutex.Dispose()
    }
}
'VM_MANAGER_JSON:' + (ConvertTo-Json -InputObject $response -Depth 12 -Compress)
